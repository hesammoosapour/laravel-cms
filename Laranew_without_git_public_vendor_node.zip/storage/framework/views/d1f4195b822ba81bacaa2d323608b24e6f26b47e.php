<!-- Footer -->
<footer class="myfooter" >
    <div class="row">
        <div class="col-lg-12">
            <p>Copyright &copy; Clock  <?php echo e(date('Y')); ?></p>
        </div>
    </div>
    <!-- /.row -->
</footer>
<?php /**PATH C:\xampp\htdocs\laranew\resources\views/includes/myfooter.blade.php ENDPATH**/ ?>
