<?php $__env->startSection('title'); ?>
    <title>Categories Clock Posts</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if(Session::has('deleted_category')): ?>
        <p class=" label-danger"><?php echo e(session('deleted_category')); ?></p>
    <?php endif; ?>
    <h1>Categories</h1>

<div class="d-flex">
    <div class="col-sm-4 ">

        <?php echo Form::open(['method'=>'POST', 'action'=> 'AdminCategoriesController@store']); ?>

             <div class="form-group">
                 <?php echo Form::label('name', 'Name:'); ?>

                 <?php echo Form::text('name', null, ['class'=>'form-control']); ?>

             </div>

             <div class="form-group">
                 <?php echo Form::submit('Create Category', ['class'=>'btn btn-primary']); ?>

             </div>
        <?php echo Form::close(); ?>


    </div>

    <div class="col-sm-8">

        <?php if($categories): ?>

            <table class="table">
                <thead>
                <tr>
                    <th>id</th>
                    <th>Name</th>
                    <th>Created date</th>
                    <th>Updated date</th>
                    <th>Deleted date</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($category->id); ?></td>
                        <td><a href="<?php echo e(route('admin.categories.edit', $category->id)); ?>"><?php echo e($category->name); ?></a></td>
                        <td><?php echo e($category->created_at ? $category->created_at->diffForHumans() : 'No date'); ?></td>
                        <td><?php echo e($category->updated_at ? $category->updated_at->diffForHumans() : 'No date'); ?></td>
                        <td><?php echo e($category->deleted_at ? $category->deleted_at->diffForHumans() : 'No date'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

        <?php endif; ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laranew\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>