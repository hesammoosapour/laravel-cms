<?php $__env->startSection('title'); ?>
    <title><?php echo e($post->title); ?> Post-Clock</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Blog Post -->

    <!-- Title -->
    <?php if(Auth::check() && Auth::user()->isAdmin()): ?>

        <h1><a href="<?php echo e(route('admin.posts.edit',$post->id)); ?>"><?php echo e($post->title); ?></a></h1>

    <?php else: ?>  <h1><?php echo e($post->title); ?></h1>
    <?php endif; ?>


    <!-- Author -->
    <p class="lead">
        Author : <a href="#"><img height="60"  src="<?php echo e($author_photo); ?>" alt=""><?php echo e($post->user ? $post->user->name : "Unknown Author"); ?></a>

        <!-- Date/Time -->
        <span ><i class="fa fa-clock-o"></i></span>
        <?php echo e($post->created_at ? "Posted : ". $post->created_at->diffForHumans() : "No date"); ?>


    </p>

    <hr>
    <!-- Preview Image -->
    <img  class="img-responsive col-xs-12 col-md-12 col-lg-10 col-sm-12 col-xl-9" src="<?php echo e($post->photo ? $post->photo->path : null); ?>" alt="">

    <hr>
    <!-- Post Content -->

    <p><?php echo $post->body; ?></p>

    <hr>
    <?php echo $__env->make('includes.comments_post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.disqus_comments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>






<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.blog-post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laranew\resources\views/post.blade.php ENDPATH**/ ?>