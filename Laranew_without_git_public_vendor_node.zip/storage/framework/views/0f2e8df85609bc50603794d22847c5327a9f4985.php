<?php $__env->startSection('title'); ?>
    <title>Admin Clock</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <h3>Administration Section </h3>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laranew\resources\views/admin/index.blade.php ENDPATH**/ ?>