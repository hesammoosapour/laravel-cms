<?php $__env->startSection('title'); ?>
    <title> Replies - Comment :  </title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php if(count($replies) > 0): ?>

        <h1>Replies for Comment : </h1>
        <div class="flex">
               <pre class="h3 "><?php echo e($replies_no); ?> Replies - <?php echo e($replies_no_active); ?> Replies Exist - <?php echo e($replies_no_approved); ?> Approved
               </pre>
        </div>

        <h4>Comment : <span class="h5"><?php echo e($comment[0]->body); ?></span></h4>

        <table class="table ">
            <thead>
            <tr>
                <th>id</th>
                <th>Replier</th>
                <th>Email</th>
                <th>Body</th>
                <th>Post Link</th>
                <th>Created</th>
                <th>Updated</th>
                <th>Deleted</th>
            </tr>
            </thead>
            <tbody>

            <?php $__currentLoopData = $replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($reply->id); ?></td>
                    <?php $replier = \App\User::whereId($replies[0]->replier_id)->first(); ?>
                    <td><?php echo e($replier->name); ?></td>
                    <td><?php echo e($replier->email); ?></td>
                    <td><?php echo e($reply->body); ?></td>
                    <td><a href="<?php echo e(route('home.post',$reply->comment->post->id)); ?>">View Post</a></td>
                    <td><?php echo e(isset($reply->created_at) ? $reply->created_at->diffForhumans() : ""); ?></td>
                    <td><?php echo e(isset($reply->updated_at) ? $reply->updated_at->diffForhumans() : ""); ?></td>
                    <td><?php echo e(isset($reply->deleted_at) ? "Deleted ".$reply->deleted_at->diffForhumans() : "Exists"); ?></td>
                    <td>
                        <?php if($reply->is_active == 1): ?>

                            <?php echo Form::open(['method'=>'PATCH', 'action'=> ['CommentRepliesController@update', $reply->id]]); ?>


                            <input type="hidden" name="is_active" value="0">

                            <div class="form-group">
                                <?php echo Form::submit('Un-approve', ['class'=>'btn btn-warning']); ?>

                            </div>
                            <?php echo Form::close(); ?>


                        <?php else: ?>

                            <?php echo Form::open(['method'=>'PATCH', 'action'=> ['CommentRepliesController@update', $reply->id]]); ?>


                            <input type="hidden" name="is_active" value="1">

                            <div class="form-group">
                                <?php echo Form::submit('Approve', ['class'=>'btn btn-success']); ?>

                            </div>
                            <?php echo Form::close(); ?>


                        <?php endif; ?>

                    </td>
                    <td>
                        <?php echo Form::open(['method'=>'DELETE', 'action'=> ['CommentRepliesController@destroy', $reply->id]]); ?>


                        <div class="form-group">
                            <?php echo Form::submit('Delete', ['class'=>'btn btn-danger']); ?>

                        </div>
                        <?php echo Form::close(); ?>


                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

    <?php else: ?>
        <h1 class="text-center">No replies</h1>

    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laranew\resources\views/admin/comments/replies/show.blade.php ENDPATH**/ ?>