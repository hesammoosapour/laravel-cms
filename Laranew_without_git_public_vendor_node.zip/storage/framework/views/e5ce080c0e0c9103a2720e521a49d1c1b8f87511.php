<h4>Comments</h4>
<?php if(Session::has('comment_message')): ?>

    <h3 class="label-warning"><?php echo e(session('comment_message')); ?> </h3>
<?php endif; ?>

<!-- Blog Comments -->

<?php if(Auth::check()): ?>

    <!-- Comments Form -->
    <div class="well d-inline-flex">

            <?php if( !empty(Auth::user()->photo()->path) || !empty(Auth::user()->gravatar) ): ?>
                <img height="60" class="media-object" src="<?php echo e(Auth::user()->gravatar ? Auth::user()->gravatar : Auth::user()->photo()->path); ?>" alt="">
                <?php else: ?>
                &nbsp;
                <h4 class="media-heading"><a href="#"><?php echo e(Auth::user()->name); ?></a></h4>
            <?php endif; ?>

        <?php echo Form::open(['method'=>'POST', 'action'=> 'PostCommentsController@store' ,'class'=>'d-inline-flex']); ?>


        <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">

        <div class="form-group">
            <?php echo Form::textarea('body', null,
            ['class'=>'form-control ','rows'=>2 ,'cols'=>'95','placeholder'=>'Leave a Comment: ',]); ?>

        </div>

        <div class="form-group">
            <?php echo Form::submit('Post', ['class'=>'btn btn-primary post_comment_btn']); ?>

        </div>
        <?php echo Form::close(); ?>


    </div>

<?php endif; ?>
<hr>
<!-- Posted Comments -->

<?php if(count($comments) > 0 ): ?>

    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Comment -->
        <div class="media">
            <div style="display: flow-root">
                <a class="d-flex" href="#" >
                    <img height="65" class="media-object" src="<?php echo e(Auth::check() && Auth::user()->gravatar ? Auth::user()->gravatar : $commenter_photo_path); ?>" alt="">


                    &nbsp; <p class="media-heading"><?php echo e($commenter->name); ?></p>
                </a>
                &nbsp;

            </div>

            <div class="media-body">


                <p class="comment_blog"><?php echo e($comment->body); ?></p>
                

                <!-- Nested Comment -->
                <div id="nested-comment" class=" media">
                    <div class="comment-reply-container col-sm-6" >

                        <button id="<?php echo e("btn-".$comment->id); ?>"  class="replycomment_btn btn btn-link pull-left text-primary">Reply
                        </button>

                        <div class="comment-reply "  id="comment-reply-<?php echo e($comment->id); ?>" >

                            <?php echo Form::open(['method'=>'POST', 'action'=> 'CommentRepliesController@createReply',
                            'class'=>'d-inline-flex']); ?>


                            <div class="form-group margin_reply_blog">

                                <input type="hidden" name="comment_id"  value="<?php echo e($comment->id); ?>">
                                <?php echo Form::label('body','Replying to '.$commenter->name); ?>

                                <?php echo Form::textarea('body', null, ['class'=>'form-control','rows'=>1]); ?>

                            </div>

                            <div class="form-group ">
                                <?php echo Form::submit('Post', ['class'=>'btn btn-primary post_reply_btn']); ?>

                            </div>
                            <?php echo Form::close(); ?>

                            <button  class="btn btn-link cancel_reply "  id="cancel-btn-<?php echo e($comment->id); ?>"> Cancel</button>
                        </div>

                        
                    </div>

                        <script>
                        $("#btn-" + <?=$comment->id?> ).click(function(){

                            $(this).next().slideToggle();

                            $("#btn-"+ <?php echo e($comment->id); ?>).hide();

                        });
                        $(document).ready(function(){
                            $("#cancel-btn-" + <?php echo e($comment->id); ?> ).click(function(){

                                $("#comment-reply-" + <?php echo e($comment->id); ?> ).fadeToggle();

                                $("#btn-"+ <?php echo e($comment->id); ?>).show(500);
                            });
                        });

                    </script>


                    <p class="col-sm-6 col-xs-0 creation_comment"><?php echo e($comment->created_at->diffForHumans()); ?></p>

                    <div class="comment_replies">
                    <?php if(count($comment->replies) > 0): ?>

                            <?php if(Session::has('reply_message')): ?>
                                <h4 class="label-warning text-center"><?php echo e(session('reply_message')); ?> </h4>

                            <?php endif; ?>
                            <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php if($reply->is_active == 1): ?>
                                        <br>
                                        <div class="media">
                                            <a class="pull-left" href="#" style="display: flex">
                                                <img height="55" class="media-object" src="<?php echo e($replier_photo_path); ?>" alt="">
                                                <p class="media-heading"><?php echo e($replier->name); ?></p>
                                            </a>
                                        </div>
                                        <div class="media-body ">
                                            <p class=""><?php echo e($reply->body); ?></p>
                                        </div>
                                        <p class="creation_reply col-sm-6 col-xs-0"><?php echo e($reply->created_at->diffForHumans()); ?></p>
                                <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="divider" style="border-top: 1px dotted #8c8b8b;"></div>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- End Nested Comment -->

            </div>
            

        </div>
        
        <br><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\laranew\resources\views/includes/comments_post.blade.php ENDPATH**/ ?>