<?php use App\Post;use App\User;?>

<?php $__env->startSection('title'); ?>
    <title>All Media - Clock Admin</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if(Session::has('deleted_photo')): ?>
        <p class="alert-danger " style="font-size: 1.7rem;">
        <?="The Photo " ."<b style='font-size:large '>" .session("deleted_photo"). "</b>" ." has been deleted";?>
        </p>
    <?php endif; ?>


    <?php if(Session::has('multi_deleted_photo')): ?>
        <p class="alert-danger " style="font-size: 1.7rem;">
            <?="The Photos " ."<b style='font-size:large '>" .session("multi_deleted_photo")."<br>" ."</b>" ."& ... have been deleted";?>
        </p>
    <?php endif; ?>

    <h2>Media</h2>

    <?php if($photos): ?>

        <form action="delete/media" method="post" class="form-inline">

            <?php echo e(csrf_field()); ?>


            <?php echo e(method_field('delete')); ?>


            <div class="form-group">
                <select name="checkBoxArray" id="" class="form-control">

                    <option value="delete" >Delete</option>

                </select>
            </div>
            <div class="form-group">
               <input type="submit" class="btn-danger btn" value="Multi Delete">
            </div>


        <table class="table  table-sm">
            <thead>
            <tr>
                <th><input type="checkbox" id="options"></th>
                <th>Id</th>
                <th>Photo</th>
                <th>Name</th>
                <th>Usage</th>
                <th>Created</th>
                <th>Updated</th>
                <th>Deleted</th>
            </tr>
            </thead>
            <tbody>

            <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><input class="checkBoxes" type="checkbox" name="checkBoxArray[]" value="<?php echo e($photo->id); ?>"></td>
                    <td><?php echo e($photo->id); ?></td>
                    <td><img height="120" width="120" src="<?php echo e($photo->path); ?>" alt=""></td>
                    <td><?php echo e(str_replace('/images/', '', $photo->path)); ?></td>

                    <?php
                    $user = User::wherePhoto_id($photo->id)->first();
                    $post = Post::wherePhoto_id($photo->id)->first();
                    ?>
                    <?php if(($post) ): ?>
                        <td><a href="<?php echo e(route('home.post',$post->slug ? $post->slug : $post->id)); ?>">
                                <?php echo e("Post : " . $post->title); ?>

                            </a>
                        </td>
                        <?php elseif($user): ?>
                        <td><a href="<?php echo e(route('admin.users.edit',$user->id)); ?>"><?php echo e('Profile : '.$user->name); ?></a></td>
                        <?php else: ?> <td><?php echo e('Source Not Found'); ?></td>
                    <?php endif; ?>


                    <td><?php echo e($photo->created_at ? $photo->created_at->diffForHumans() : 'No date'); ?></td>
                    <td><?php echo e($photo->updated_at ? $photo->updated_at->diffForHumans() : 'No date'); ?></td>
                    <td><?php echo e($photo->deleted_at ? $photo->deleted_at->diffForHumans() : 'No date'); ?></td>
                    <td>

                        <?php echo Form::open(['method'=>'DELETE', 'action'=> ['AdminMediasController@destroy', $photo->id]]); ?>


                        <div class="form-group">
                            <?php echo Form::submit('Delete', ['class'=>'btn btn-danger']); ?>

                        </div>
                        <?php echo Form::close(); ?>

                    </td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

        </form>

    <?php endif; ?>
    <div class="row">
        <div class="col-sm-6 col-sm-offset-5">

            <?php echo e($photos->render()); ?>


        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function(){
            $('#options').click(function(){
                if(this.checked){
                    $('.checkBoxes').each(function(){
                        this.checked = true;});
                }else {
                    $('.checkBoxes').each(function(){
                        this.checked = false;
                    });
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laranew\resources\views/admin/media/index.blade.php ENDPATH**/ ?>