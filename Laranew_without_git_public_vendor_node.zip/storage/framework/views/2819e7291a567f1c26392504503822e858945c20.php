<?php $__env->startSection('title'); ?>
    <title>Post Comments</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php if(count($comments)  > 0): ?>

        <h1>Post Comments</h1>
        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $result= DB::select('SELECT `title` FROM `posts` WHERE `id` =? ', [$comment->post_id]) ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       <div class="flex">
           <h3>Post Title : <a href="<?php echo e(route('home.post',$comment->post->id)); ?>"><?php $res = $result[0];echo $res->title; ?>
               </a></h3>

           <div class="flex">
               <pre class="h3 "><?php echo e($comments_no); ?> Comment(s) - <?php echo e($comments_no_active); ?>  Exist(s) - <?php echo e($comments_no_approved); ?> Approved
               </pre>
           </div>
       </div>
        <table class="table">
            <thead>
            <tr>
                <th>id</th>
                <th>Author</th>
                <th>Email</th>
                <th>Comment</th>
                <th>Created</th>
                <th>Updated</th>
                <th>Deleted</th>
            </tr>
            </thead>
            <tbody>

            <?php $__currentLoopData = $all_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($comment->id); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($comment->body); ?></td>
                    <td><?php echo e(isset($comment->created_at) ? $comment->created_at->diffForhumans() : ""); ?></td>
                    <td><?php echo e(isset($comment->updated_at) ? $comment->updated_at->diffForhumans() : ""); ?></td>
                    <td><?php echo e(isset($comment->deleted_at) ? "Deleted ".$comment->deleted_at->diffForhumans() : "Exists"); ?></td>
                    <td>

                        <?php if($comment->is_active == 1): ?>

                            <?php echo Form::open(['method'=>'PATCH', 'action'=> ['PostCommentsController@update', $comment->id]]); ?>


                            <input type="hidden" name="is_active" value="0">

                            <div class="form-group">
                                <?php echo Form::submit('Un-approve', ['class'=>'btn btn-warning']); ?>

                            </div>
                            <?php echo Form::close(); ?>


                        <?php else: ?>

                            <?php echo Form::open(['method'=>'PATCH', 'action'=> ['PostCommentsController@update', $comment->id]]); ?>


                            <input type="hidden" name="is_active" value="1">

                            <div class="form-group">
                                <?php echo Form::submit('Approve', ['class'=>'btn btn-success']); ?>

                            </div>
                            <?php echo Form::close(); ?>


                        <?php endif; ?>

                    </td>

                    <td>

                        <?php echo Form::open(['method'=>'DELETE', 'action'=> ['PostCommentsController@destroy', $comment->id]]); ?>



                        <div class="form-group">
                            <?php echo Form::submit('Delete', ['class'=>'btn btn-danger']); ?>

                        </div>
                        <?php echo Form::close(); ?>


                    </td>

                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

    <?php else: ?>

        <h1 class="text-center">No Comments</h1>

    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laranew\resources\views/admin/comments/show.blade.php ENDPATH**/ ?>