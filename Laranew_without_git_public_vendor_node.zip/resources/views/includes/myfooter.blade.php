<!-- Footer -->
<footer class="myfooter" >
    <div class="row">
        <div class="col-lg-12">
            <p>Copyright &copy; Clock  {{date('Y')}}</p>
        </div>
    </div>
    <!-- /.row -->
</footer>
