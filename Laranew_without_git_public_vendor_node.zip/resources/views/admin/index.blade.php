@extends('layouts.admin')
@section('title')
    <title>Admin Clock</title>
@stop
@section('content')


    <h3>Administration Section </h3>


@stop
